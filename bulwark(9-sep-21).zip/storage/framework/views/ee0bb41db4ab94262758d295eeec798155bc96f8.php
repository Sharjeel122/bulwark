
<div class="form-group">
    <label class="form-labels" for="username"><strong>Full Name*:</strong></label>
    <input type="text" class="form-control form-feilds" name="name" placeholder="Enter Full Name" value="<?php echo e($employee->name); ?>">
    <?php if($errors->has('name')): ?>
        <span role="alert">
              <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>
         </span>
    <?php endif; ?>
</div>

<div class="form-group">
    <label class="form-labels" for="username"><strong>Email*:</strong></label>
    <input type="text" class="form-control form-feilds" name="email" placeholder="Enter Email" value="<?php echo e($employee->email); ?>">
    <?php if($errors->has('email')): ?>
        <span role="alert">
              <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>
         </span>
    <?php endif; ?>
</div>

<div class="form-group">
    <label class="form-labels" for="username"><strong>Contact:</strong></label>
    <input type="tel" class="form-control form-feilds" name="contact" placeholder="Enter Contact#" value="<?php echo e($employee->contact); ?>">
</div>
<?php /**PATH /home2/majidfaz/public_html/edenspell.com/cyber-bulwark/resources/views/admin/employee/_form.blade.php ENDPATH**/ ?>