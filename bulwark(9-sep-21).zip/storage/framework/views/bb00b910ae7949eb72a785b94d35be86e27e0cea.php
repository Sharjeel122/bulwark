<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="dashboard-right-scroll-contetn container-fluid">
         <?php if(session()->has('alert-success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('alert-success')); ?>

            </div>
        <?php endif; ?>
    <div class="row">
      <div class="col-lg-6 col-md-6  col-sm-6 col-8 my-auto">
          <div class="dashboard-right-title-tag">
              <h6 class="mb-0">All Customer</h6>
           </div>
      </div>
       <div class="col-lg-6 col-md-6 col-sm-6 col-4 text-right">
            <!-- <button type="file"> Upload</button>   -->

             <a href="<?php echo e(route('admin.create.employee')); ?>"><label class="choose-file"><i class="fa fa-user-plus"></i> Add </label></a>
        </div>
   </div>
         <hr>
               <div class="dasboard-right-main-contetent-area">
        <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
            <thead>
                <tr>
                     <th style="width:20px;"><input type="checkbox"></th>
                     <th style="width:20px;">No.</th>
                     <th>Employee Name</th>
                     <th>Email</th>
                     <th>Contact</th>

                     <th>Action</th>
                </tr>
            </thead>
                <tbody>
                  <?php
                    $i = 1;
                  ?>
                  <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td ><input type="checkbox"></td>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($employee->name); ?></td>
                        <td><?php echo e($employee->email); ?></td>
                        <td><?php echo e($employee->contact); ?></td>

                        <td class="text-right">
                            <a href="<?php echo e(route('admin.edit.employee', $employee->id)); ?>" class="btn btn-sm btn-outline-info" title="Edit Customer Detail"><i class="fa fa-edit"></i></a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/majidfaz/public_html/edenspell.com/cyber-bulwark/resources/views/admin/employee/all-employees.blade.php ENDPATH**/ ?>