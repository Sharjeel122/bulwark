<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="dashboard-right-scroll-contetn container-fluid">
         <?php if(session()->has('alert-success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('alert-success')); ?>

            </div>
        <?php endif; ?>

             <?php
                 $websites = \App\Models\Website::where(['user_id' => Auth::user()->id, 'website_data' => NULL])->get();

                 if($websites->count() > 0){
                     echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
                         <h6>Please provide Website credentails so that we continue</h6>
                         <ol>";
                             foreach($websites as $website){
                                 echo "<li><a href='".route('website.details', $website->id)."'><u>$website->website</u></a></li>";
                             }
                     echo "</ol>
                         <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                             <span aria-hidden='true'>&times;</span>
                         </button>
                     </div>";
                 }
             ?>
    <div class="row">
      <div class="col-lg-6 col-md-6  col-sm-6 col-8 my-auto">
          <div class="dashboard-right-title-tag">
              <h6 class="mb-0">Profile Information</h6>
           </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-4 text-right">

      </div>
   </div>
         <hr>
               <div class="dasboard-right-main-contetent-area">
        <form  class="row" action="<?php echo e(route('customer.update', Auth::user()->id )); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="col-md-4 col-lg-4 col-sm-4 col-12 pb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>">
            </div>
            <div class="col-md-4 col-lg-4 col-sm-4 col-12 pb-3">
                <label>Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
            </div>
            <div class="col-md-6 col-lg-6 col-sm-6 col-12 pb-3">
                <label>Contact</label>
                <input type="text" name="contact" class="form-control" value="<?php echo e(Auth::user()->contact); ?>">
            </div>
            <div class="col-md-4 col-lg-4 col-sm-4 col-12 pb-3">
                <label>Password</label>
                <input type="text" name="password" class="form-control" >
            </div>
            <div class="col-md-12 col-lg-12 col-sm-12 col-12 pt-3">
            <button type="submit" class="btn btn-default-blue w-2">Add</button>
        </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/majidfaz/public_html/edenspell.com/cyber-bulwark/resources/views/customer/dashboard.blade.php ENDPATH**/ ?>