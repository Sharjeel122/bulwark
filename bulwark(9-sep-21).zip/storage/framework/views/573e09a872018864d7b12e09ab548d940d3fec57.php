<!-- dashbaord sidebar   -->
<div class="dashboard-sidebar">
    <div class="dashboard-sidebar">
        <small class="credit">Design & Developed By: <a href="https://edenspell.com/" target="blank">Eden Spell
                Technologies</a></small>
        <div class="admin-detail-area">
            <div class="admin-name-area">
                <h2 class="text-white mb-0"><i class="fa fa-user"></i> <?php echo e(Auth::user()->name); ?></h2>
                <h2 class="online-active mb-0"><i class=""></i> Online</h2>

            </div>
        </div>
        <div class="sidebar-link-area">
            <ul class="sidear-link-list">
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <li class="<?php echo e(Request::is('admin') ? 'active' : ''); ?> sidear-link-list-items "><a href="<?php echo e(route('admin.index')); ?>"><i
                            class="fa fa-tachometer"></i> Dashborad</a></li>
                <li class="<?php echo e(Request::is('admin-all-customers') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('admin.customers')); ?>"><i class="fa fa-eye"></i>
                        View Customers</a></li>
                <li class="<?php echo e(Request::is('admin-all-leads') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('admin.leads')); ?>"><i
                            class="fa fa-user-secret"></i> View Leads</a></li>
                <li class="<?php echo e(Request::is('admin-all-employees') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('admin.employees')); ?>"><i
                            class="fa fa-smile-o"></i> View Employees</a></li>
                <li class="<?php echo e(Request::is('admin-support-tickers') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('admin.support.tickers')); ?>"><i
                            class="fa fa-ticket"></i> Support Ticket</a></li>
                <li class="<?php echo e(Request::is('paypal-plan') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('paypal-plan.index')); ?>"><i
                            class="fa fa-handshake-o"></i> Plans</a></li>
                              <li class="<?php echo e(Request::is('reports') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('admin.reports')); ?>"><i
                            class="fa fa-flag-o"></i> Upload Report</a></li>
                <?php endif; ?>

                <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
                <li class="<?php echo e(Request::is('customer') ? 'active' : ''); ?> sidear-link-list-items "><a href="<?php echo e(route('customer.index')); ?>"><i
                            class="fa fa-tachometer"></i> Dashborad</a></li>
                <li class="<?php echo e(Request::is('support-tickers') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('customer.support.tickers')); ?>"><i
                            class="fa fa-ticket"></i> Support Ticket</a></li>
                <li class="<?php echo e(Request::is('websites') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('customer.website')); ?>"><i
                            class="fa fa-globe"></i> My Websites</a></li>
                             <li class="<?php echo e(Request::is('view-reports') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('customer.reports')); ?>"><i
                            class="fa fa-flag-o"></i> View Report</a></li>
                <?php endif; ?>

                    
                <?php if(auth()->check() && auth()->user()->hasRole('employee1|employee2')): ?>
                <li class="<?php echo e(Request::is('employee') ? 'active' : ''); ?> sidear-link-list-items "><a href="<?php echo e(route('employee.index')); ?>"><i
                            class="fa fa-tachometer"></i> Dashborad</a></li>
                <li class="<?php echo e(Request::is('employee-reports') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('employee.reports')); ?>"><i
                            class="fa fa-flag-o"></i> Upload Report</a></li>
                <li class="<?php echo e(Request::is('employee-support-tickers') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('employee.support.tickers')); ?>"><i
                            class="fa fa-ticket"></i> Support Ticket</a></li>
                             <li class="<?php echo e(Request::is('employee-all-customers') ? 'active' : ''); ?> sidear-link-list-items  "><a href="<?php echo e(route('employee.customers')); ?>"><i class="fa fa-eye"></i>
                        View Customers</a></li>
                <?php endif; ?>
                    

                <?php if(auth()->check() && auth()->user()->hasRole('employee1')): ?>
               
                <?php endif; ?>

                <li class="sidear-link-list-items "><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>

            </ul>
            <hr class="admin-sidbar-lines">
            <!-- <ul class="sidear-link-list">
                <li class="sidear-link-list-items"><a href="account-setting.html"><i class="fa fa-cog"></i> Account Setting</a></li>
                <li class="sidear-link-list-items "><a href="#"><i class="fa fa-sign-out"></i> Logout</a></li>
            </ul> -->
        </div>
    </div>
</div>
<?php /**PATH /home2/majidfaz/public_html/edenspell.com/cyber-bulwark/resources/views/layouts/includes/sidebar.blade.php ENDPATH**/ ?>