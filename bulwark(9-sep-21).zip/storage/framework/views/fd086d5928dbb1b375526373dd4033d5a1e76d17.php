<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="dashboard-right-scroll-contetn container-fluid">
         <?php if(session()->has('alert-success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('alert-success')); ?>

            </div>
        <?php endif; ?>
    <div class="row">
      <div class="col-lg-6 col-md-6  col-sm-6 col-8 my-auto">
          <div class="dashboard-right-title-tag">
              <h6 class="mb-0"><?php echo e($website_detail->website); ?> Detail</h6>
           </div>
      </div>
       <div class="col-lg-6 col-md-6 col-sm-6 col-4 text-right">
            <!-- <button type="file"> Upload</button>   -->

             
        </div>
   </div>
    <hr>
    <div class="dasboard-right-main-contetent-area">
        <div class="row">
            <div class="col-md-12">
                <div class="card p-0">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6"><b>My Website: </b><?php echo e($website_detail->website); ?></div>
                            <div class="col-md-6"><b>Payment Status: </b><?php echo e($website_detail->payment); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6"><b>Subscription Date: </b><?php echo e($website_detail->subscription_date); ?></div>
                            <div class="col-md-6"><b>Amount: </b><?php echo e($website_detail->amount); ?> $</div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6"><b>Status: </b>
                                <?php if($website_detail->status == 0): ?>
                                    Active
                                <?php else: ?>
                                    Lead
                                <?php endif; ?>
                            </div>
                            
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12"><b>Website Data: </b><br />
                                <?php echo e($website_detail->website_data); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/majidfaz/public_html/edenspell.com/cyber-bulwark/resources/views/customer/website/website-detail.blade.php ENDPATH**/ ?>