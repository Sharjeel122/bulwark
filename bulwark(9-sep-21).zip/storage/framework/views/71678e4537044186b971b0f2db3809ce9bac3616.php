<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notificaiton</title>

    <style>
        *{
            margin: 0 auto;
            box-sizing: border-box;
        }
        .reminder-email{
            padding:20px;
        }
    </style>
</head>
<body>
<div class="container" style="width:70%; background-color: white; border: 1px solid black;">
    <div class="head" style="background-color: #F05A22; padding: 10px; text-align: center; color: black; font-size: 22px;">
        <h2>Cyber Bulwark</h2>
    </div>
    <div class="body reminder-email" style="margin-top: 20px;">
        <h2 style="text-align: center;"><b>Reminder Notification</b></h2>
        Hi ali,<br />
        This is a Reminder email we are waiting for your reply about the credentials
        <br /><br />
        We received a request to start working on your website (https://test.com/)
        but unfortunately we are unable to login on Client/Webite panel due to incomplete/wrong website credentials.
        <br /><br />
        kindly check and resend credentials so we will start work on it.<br />
        Thank You,<br />
        Bulwark Support Team


    </div>
</div>
</body>
</html>
<?php /**PATH /home2/majidfaz/public_html/edenspell.com/cyber-bulwark/resources/views/email/reminder-email-template.blade.php ENDPATH**/ ?>